create function indexar_entrevista_individual() returns trigger
    language plpgsql
as
$$
begin
  new.fts :=
    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.titulo,'')), 'A') ||
    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.html_transcripcion,'')), 'B') ||
    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.anotaciones,'')), 'C') ||
    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.observaciones_diligenciada,'')), 'D');
 return new;
end
$$;

alter function indexar_entrevista_individual() owner to dba;

