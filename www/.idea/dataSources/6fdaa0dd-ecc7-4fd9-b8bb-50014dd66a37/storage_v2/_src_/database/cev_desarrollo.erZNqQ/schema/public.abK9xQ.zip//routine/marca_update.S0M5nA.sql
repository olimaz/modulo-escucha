create function marca_update() returns trigger
    language plpgsql
as
$$
BEGIN
   NEW.fh_update = now();
   RETURN NEW;
END;
$$;

alter function marca_update() owner to postgres;

