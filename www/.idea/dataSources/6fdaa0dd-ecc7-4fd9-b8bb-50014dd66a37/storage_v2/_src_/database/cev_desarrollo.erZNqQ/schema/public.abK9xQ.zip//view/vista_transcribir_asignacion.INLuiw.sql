create view vista_transcribir_asignacion
            (id, autoriza_id, autoriza_txt, transcriptor_id, transcriptor_codigo, transcriptor_nombre, estado_id,
             estado_txt, causa_id, causa_txt, urgente_id, urgente_txt, observaciones, fh_asignado, fh_asignado_mes,
             fh_asignado_dia, fh_asignado_semana, fh_transcrito, fh_transcrito_mes, fh_transcrito_dia,
             fh_transcrito_semana, fh_inicio, fh_fin, duracion_entrevista_minutos, duracion_transcripcion_minutos,
             duracion_transcripcion_real_minutos, terceros_id, terceros_txt, entrevista_codigo)
as
SELECT t.id_transcribir_asignacion                  AS id,
       t.id_autoriza                                AS autoriza_id,
       a.numero_entrevistador                       AS autoriza_txt,
       t.id_transcriptor                            AS transcriptor_id,
       tr.numero_entrevistador                      AS transcriptor_codigo,
       u.name                                       AS transcriptor_nombre,
       t.id_situacion                               AS estado_id,
       cf.descripcion                               AS estado_txt,
       t.id_causa                                   AS causa_id,
       c.descripcion                                AS causa_txt,
       t.urgente                                    AS urgente_id,
       CASE
           WHEN t.urgente = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS urgente_txt,
       t.observaciones,
       t.fh_asignado,
       to_char(t.fh_asignado, 'yyyy-mm'::text)      AS fh_asignado_mes,
       to_char(t.fh_asignado, 'yyyy-mm-dd'::text)   AS fh_asignado_dia,
       to_char(t.fh_asignado, 'IYYY-IW'::text)      AS fh_asignado_semana,
       t.fh_transcrito,
       to_char(t.fh_transcrito, 'yyyy-mm'::text)    AS fh_transcrito_mes,
       to_char(t.fh_transcrito, 'yyyy-mm-dd'::text) AS fh_transcrito_dia,
       to_char(t.fh_transcrito, 'IYYY-IW'::text)    AS fh_transcrito_semana,
       t.fh_inicio,
       t.fh_fin,
       t.duracion_entrevista_minutos,
       t.duracion_transcripcion_minutos,
       t.duracion_transcripcion_real_minutos,
       t.terceros                                   AS terceros_id,
       CASE
           WHEN t.terceros = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS terceros_txt,
       e.entrevista_codigo
FROM transcribir_asignacion t
         JOIN esclarecimiento.entrevistador a ON t.id_autoriza = a.id_entrevistador
         JOIN esclarecimiento.entrevistador tr ON t.id_transcriptor = tr.id_entrevistador
         JOIN users u ON tr.id_usuario = u.id
         JOIN catalogos.criterio_fijo cf ON t.id_situacion = cf.id_opcion AND cf.id_grupo = 8
         LEFT JOIN catalogos.cat_item c ON t.id_causa = c.id_item
         JOIN esclarecimiento.e_ind_fvt e ON t.id_e_ind_fvt = e.id_e_ind_fvt
UNION
SELECT t.id_transcribir_asignacion                  AS id,
       t.id_autoriza                                AS autoriza_id,
       a.numero_entrevistador                       AS autoriza_txt,
       t.id_transcriptor                            AS transcriptor_id,
       tr.numero_entrevistador                      AS transcriptor_codigo,
       u.name                                       AS transcriptor_nombre,
       t.id_situacion                               AS estado_id,
       cf.descripcion                               AS estado_txt,
       t.id_causa                                   AS causa_id,
       c.descripcion                                AS causa_txt,
       t.urgente                                    AS urgente_id,
       CASE
           WHEN t.urgente = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS urgente_txt,
       t.observaciones,
       t.fh_asignado,
       to_char(t.fh_asignado, 'yyyy-mm'::text)      AS fh_asignado_mes,
       to_char(t.fh_asignado, 'yyyy-mm-dd'::text)   AS fh_asignado_dia,
       to_char(t.fh_asignado, 'IYYY-IW'::text)      AS fh_asignado_semana,
       t.fh_transcrito,
       to_char(t.fh_transcrito, 'yyyy-mm'::text)    AS fh_transcrito_mes,
       to_char(t.fh_transcrito, 'yyyy-mm-dd'::text) AS fh_transcrito_dia,
       to_char(t.fh_transcrito, 'IYYY-IW'::text)    AS fh_transcrito_semana,
       t.fh_inicio,
       t.fh_fin,
       t.duracion_entrevista_minutos,
       t.duracion_transcripcion_minutos,
       t.duracion_transcripcion_real_minutos,
       t.terceros                                   AS terceros_id,
       CASE
           WHEN t.terceros = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS terceros_txt,
       e.entrevista_codigo
FROM transcribir_asignacion t
         JOIN esclarecimiento.entrevistador a ON t.id_autoriza = a.id_entrevistador
         JOIN esclarecimiento.entrevistador tr ON t.id_transcriptor = tr.id_entrevistador
         JOIN users u ON tr.id_usuario = u.id
         JOIN catalogos.criterio_fijo cf ON t.id_situacion = cf.id_opcion AND cf.id_grupo = 8
         LEFT JOIN catalogos.cat_item c ON t.id_causa = c.id_item
         JOIN esclarecimiento.entrevista_profundidad e ON t.id_entrevista_profundidad = e.id_entrevista_profundidad
UNION
SELECT t.id_transcribir_asignacion                  AS id,
       t.id_autoriza                                AS autoriza_id,
       a.numero_entrevistador                       AS autoriza_txt,
       t.id_transcriptor                            AS transcriptor_id,
       tr.numero_entrevistador                      AS transcriptor_codigo,
       u.name                                       AS transcriptor_nombre,
       t.id_situacion                               AS estado_id,
       cf.descripcion                               AS estado_txt,
       t.id_causa                                   AS causa_id,
       c.descripcion                                AS causa_txt,
       t.urgente                                    AS urgente_id,
       CASE
           WHEN t.urgente = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS urgente_txt,
       t.observaciones,
       t.fh_asignado,
       to_char(t.fh_asignado, 'yyyy-mm'::text)      AS fh_asignado_mes,
       to_char(t.fh_asignado, 'yyyy-mm-dd'::text)   AS fh_asignado_dia,
       to_char(t.fh_asignado, 'IYYY-IW'::text)      AS fh_asignado_semana,
       t.fh_transcrito,
       to_char(t.fh_transcrito, 'yyyy-mm'::text)    AS fh_transcrito_mes,
       to_char(t.fh_transcrito, 'yyyy-mm-dd'::text) AS fh_transcrito_dia,
       to_char(t.fh_transcrito, 'IYYY-IW'::text)    AS fh_transcrito_semana,
       t.fh_inicio,
       t.fh_fin,
       t.duracion_entrevista_minutos,
       t.duracion_transcripcion_minutos,
       t.duracion_transcripcion_real_minutos,
       t.terceros                                   AS terceros_id,
       CASE
           WHEN t.terceros = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS terceros_txt,
       e.entrevista_codigo
FROM transcribir_asignacion t
         JOIN esclarecimiento.entrevistador a ON t.id_autoriza = a.id_entrevistador
         JOIN esclarecimiento.entrevistador tr ON t.id_transcriptor = tr.id_entrevistador
         JOIN users u ON tr.id_usuario = u.id
         JOIN catalogos.criterio_fijo cf ON t.id_situacion = cf.id_opcion AND cf.id_grupo = 8
         LEFT JOIN catalogos.cat_item c ON t.id_causa = c.id_item
         JOIN esclarecimiento.entrevista_colectiva e ON t.id_entrevista_colectiva = e.id_entrevista_colectiva
UNION
SELECT t.id_transcribir_asignacion                  AS id,
       t.id_autoriza                                AS autoriza_id,
       a.numero_entrevistador                       AS autoriza_txt,
       t.id_transcriptor                            AS transcriptor_id,
       tr.numero_entrevistador                      AS transcriptor_codigo,
       u.name                                       AS transcriptor_nombre,
       t.id_situacion                               AS estado_id,
       cf.descripcion                               AS estado_txt,
       t.id_causa                                   AS causa_id,
       c.descripcion                                AS causa_txt,
       t.urgente                                    AS urgente_id,
       CASE
           WHEN t.urgente = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS urgente_txt,
       t.observaciones,
       t.fh_asignado,
       to_char(t.fh_asignado, 'yyyy-mm'::text)      AS fh_asignado_mes,
       to_char(t.fh_asignado, 'yyyy-mm-dd'::text)   AS fh_asignado_dia,
       to_char(t.fh_asignado, 'IYYY-IW'::text)      AS fh_asignado_semana,
       t.fh_transcrito,
       to_char(t.fh_transcrito, 'yyyy-mm'::text)    AS fh_transcrito_mes,
       to_char(t.fh_transcrito, 'yyyy-mm-dd'::text) AS fh_transcrito_dia,
       to_char(t.fh_transcrito, 'IYYY-IW'::text)    AS fh_transcrito_semana,
       t.fh_inicio,
       t.fh_fin,
       t.duracion_entrevista_minutos,
       t.duracion_transcripcion_minutos,
       t.duracion_transcripcion_real_minutos,
       t.terceros                                   AS terceros_id,
       CASE
           WHEN t.terceros = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS terceros_txt,
       e.entrevista_codigo
FROM transcribir_asignacion t
         JOIN esclarecimiento.entrevistador a ON t.id_autoriza = a.id_entrevistador
         JOIN esclarecimiento.entrevistador tr ON t.id_transcriptor = tr.id_entrevistador
         JOIN users u ON tr.id_usuario = u.id
         JOIN catalogos.criterio_fijo cf ON t.id_situacion = cf.id_opcion AND cf.id_grupo = 8
         LEFT JOIN catalogos.cat_item c ON t.id_causa = c.id_item
         JOIN esclarecimiento.entrevista_etnica e ON t.id_entrevista_etnica = e.id_entrevista_etnica
UNION
SELECT t.id_transcribir_asignacion                  AS id,
       t.id_autoriza                                AS autoriza_id,
       a.numero_entrevistador                       AS autoriza_txt,
       t.id_transcriptor                            AS transcriptor_id,
       tr.numero_entrevistador                      AS transcriptor_codigo,
       u.name                                       AS transcriptor_nombre,
       t.id_situacion                               AS estado_id,
       cf.descripcion                               AS estado_txt,
       t.id_causa                                   AS causa_id,
       c.descripcion                                AS causa_txt,
       t.urgente                                    AS urgente_id,
       CASE
           WHEN t.urgente = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS urgente_txt,
       t.observaciones,
       t.fh_asignado,
       to_char(t.fh_asignado, 'yyyy-mm'::text)      AS fh_asignado_mes,
       to_char(t.fh_asignado, 'yyyy-mm-dd'::text)   AS fh_asignado_dia,
       to_char(t.fh_asignado, 'IYYY-IW'::text)      AS fh_asignado_semana,
       t.fh_transcrito,
       to_char(t.fh_transcrito, 'yyyy-mm'::text)    AS fh_transcrito_mes,
       to_char(t.fh_transcrito, 'yyyy-mm-dd'::text) AS fh_transcrito_dia,
       to_char(t.fh_transcrito, 'IYYY-IW'::text)    AS fh_transcrito_semana,
       t.fh_inicio,
       t.fh_fin,
       t.duracion_entrevista_minutos,
       t.duracion_transcripcion_minutos,
       t.duracion_transcripcion_real_minutos,
       t.terceros                                   AS terceros_id,
       CASE
           WHEN t.terceros = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS terceros_txt,
       e.entrevista_codigo
FROM transcribir_asignacion t
         JOIN esclarecimiento.entrevistador a ON t.id_autoriza = a.id_entrevistador
         JOIN esclarecimiento.entrevistador tr ON t.id_transcriptor = tr.id_entrevistador
         JOIN users u ON tr.id_usuario = u.id
         JOIN catalogos.criterio_fijo cf ON t.id_situacion = cf.id_opcion AND cf.id_grupo = 8
         LEFT JOIN catalogos.cat_item c ON t.id_causa = c.id_item
         JOIN esclarecimiento.diagnostico_comunitario e ON t.id_diagnostico_comunitario = e.id_diagnostico_comunitario
UNION
SELECT t.id_transcribir_asignacion                  AS id,
       t.id_autoriza                                AS autoriza_id,
       a.numero_entrevistador                       AS autoriza_txt,
       t.id_transcriptor                            AS transcriptor_id,
       tr.numero_entrevistador                      AS transcriptor_codigo,
       u.name                                       AS transcriptor_nombre,
       t.id_situacion                               AS estado_id,
       cf.descripcion                               AS estado_txt,
       t.id_causa                                   AS causa_id,
       c.descripcion                                AS causa_txt,
       t.urgente                                    AS urgente_id,
       CASE
           WHEN t.urgente = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS urgente_txt,
       t.observaciones,
       t.fh_asignado,
       to_char(t.fh_asignado, 'yyyy-mm'::text)      AS fh_asignado_mes,
       to_char(t.fh_asignado, 'yyyy-mm-dd'::text)   AS fh_asignado_dia,
       to_char(t.fh_asignado, 'IYYY-IW'::text)      AS fh_asignado_semana,
       t.fh_transcrito,
       to_char(t.fh_transcrito, 'yyyy-mm'::text)    AS fh_transcrito_mes,
       to_char(t.fh_transcrito, 'yyyy-mm-dd'::text) AS fh_transcrito_dia,
       to_char(t.fh_transcrito, 'IYYY-IW'::text)    AS fh_transcrito_semana,
       t.fh_inicio,
       t.fh_fin,
       t.duracion_entrevista_minutos,
       t.duracion_transcripcion_minutos,
       t.duracion_transcripcion_real_minutos,
       t.terceros                                   AS terceros_id,
       CASE
           WHEN t.terceros = 1 THEN 'Sí'::text
           ELSE 'No'::text
           END                                      AS terceros_txt,
       e.entrevista_codigo
FROM transcribir_asignacion t
         JOIN esclarecimiento.entrevistador a ON t.id_autoriza = a.id_entrevistador
         JOIN esclarecimiento.entrevistador tr ON t.id_transcriptor = tr.id_entrevistador
         JOIN users u ON tr.id_usuario = u.id
         JOIN catalogos.criterio_fijo cf ON t.id_situacion = cf.id_opcion AND cf.id_grupo = 8
         LEFT JOIN catalogos.cat_item c ON t.id_causa = c.id_item
         JOIN esclarecimiento.historia_vida e ON t.id_historia_vida = e.id_historia_vida
ORDER BY 29;

alter table vista_transcribir_asignacion
    owner to dba;

