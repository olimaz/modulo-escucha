create function indexar_entrevista_etnica() returns trigger
    language plpgsql
as
$$
begin
    new.fts :=
                        setweight(to_tsvector('pg_catalog.spanish',coalesce(new.titulo,'')), 'A') ||
                        setweight(to_tsvector('pg_catalog.spanish',coalesce(new.html_transcripcion,'')), 'B') ||
                        setweight(to_tsvector('pg_catalog.spanish',coalesce(new.tema_descripcion,'')), 'C') ||
                        setweight(to_tsvector('pg_catalog.spanish',coalesce(new.tema_objetivo,'')), 'C') ||
                        setweight(to_tsvector('pg_catalog.spanish',coalesce(new.eventos_descripcion,'')), 'C') ||
                        setweight(to_tsvector('pg_catalog.spanish',coalesce(new.observaciones,'')), 'D');
    return new;
end
$$;

alter function indexar_entrevista_etnica() owner to dba;

