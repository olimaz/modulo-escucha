create function marca_insert() returns trigger
    language plpgsql
as
$$
BEGIN
   NEW.fh_insert = now();
   RETURN NEW;
END;
$$;

alter function marca_insert() owner to postgres;

