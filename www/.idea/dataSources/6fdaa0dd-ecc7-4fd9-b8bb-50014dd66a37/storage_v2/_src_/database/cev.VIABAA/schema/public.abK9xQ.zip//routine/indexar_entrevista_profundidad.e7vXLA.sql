create function indexar_entrevista_profundidad() returns trigger
    language plpgsql
as
$$
begin
    new.fts :=
                    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.titulo,'')), 'A') ||
                    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.entrevista_objetivo,'')), 'A') ||
                    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.entrevistado_apellidos,'')), 'A') ||
                    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.entrevistado_nombres,'')), 'A') ||
                    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.html_transcripcion,'')), 'B') ||
                    setweight(to_tsvector('pg_catalog.spanish',coalesce(new.observaciones,'')), 'C') ;
    return new;
end
$$;

alter function indexar_entrevista_profundidad() owner to dba;

