create function indexar_historia_vida() returns trigger
    language plpgsql
as
$$
begin
    new.fts :=
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.titulo,'')), 'A') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.entrevistado_nombres,'')), 'B') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.entrevistado_apellidos,'')), 'B') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.entrevistado_otros_nombres,'')), 'B') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.entrevista_objetivo,'')), 'C') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.html_transcripcion,'')), 'C') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.observaciones,'')), 'D') ;
    return new;
end
$$;

alter function indexar_historia_vida() owner to dba;

