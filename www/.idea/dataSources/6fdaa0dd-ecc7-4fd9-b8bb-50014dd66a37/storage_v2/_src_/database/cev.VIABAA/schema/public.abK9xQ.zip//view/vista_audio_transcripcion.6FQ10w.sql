create view vista_audio_transcripcion
            (id_e_ind_fvt, entrevista_codigo, audio_ubicacion, audio_nombre, transcripcion_ubicacion, macroterritorio,
             territorio) as
SELECT e.id_e_ind_fvt,
       e.entrevista_codigo,
       adjunto.ubicacion       AS audio_ubicacion,
       adjunto.nombre_original AS audio_nombre,
       adjunto2.ubicacion      AS transcripcion_ubicacion,
       m.descripcion           AS macroterritorio,
       cev.descripcion         AS territorio
FROM esclarecimiento.e_ind_fvt e
         JOIN esclarecimiento.e_ind_fvt_adjunto a ON e.id_e_ind_fvt = a.id_e_ind_fvt AND a.id_tipo = 2
         JOIN transcribir_asignacion t ON e.id_e_ind_fvt = t.id_e_ind_fvt AND t.id_situacion = 2
         JOIN esclarecimiento.adjunto ON a.id_adjunto = adjunto.id_adjunto
         JOIN esclarecimiento.e_ind_fvt_adjunto a2 ON e.id_e_ind_fvt = a2.id_e_ind_fvt AND a2.id_tipo = 6
         JOIN esclarecimiento.adjunto adjunto2 ON a2.id_adjunto = adjunto2.id_adjunto
         JOIN catalogos.cev m ON e.id_macroterritorio = m.id_geo
         JOIN catalogos.cev ON e.id_territorio = cev.id_geo
WHERE adjunto2.ubicacion::text ~~* '%html'::text
ORDER BY e.entrevista_codigo, adjunto2.nombre_original;

alter table vista_audio_transcripcion
    owner to dba;

