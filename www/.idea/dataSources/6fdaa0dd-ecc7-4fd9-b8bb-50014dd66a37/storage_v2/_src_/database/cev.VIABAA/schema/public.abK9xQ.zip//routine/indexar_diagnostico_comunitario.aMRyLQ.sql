create function indexar_diagnostico_comunitario() returns trigger
    language plpgsql
as
$$
begin
    new.fts :=
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.titulo,'')), 'A') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.tema_comunidad,'')), 'B') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.tema_objetivo,'')), 'B') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.tema_dinamica,'')), 'B') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.html_transcripcion,'')), 'C') ||
                                setweight(to_tsvector('pg_catalog.spanish',coalesce(new.observaciones,'')), 'D') ;
    return new;
end
$$;

alter function indexar_diagnostico_comunitario() owner to dba;

